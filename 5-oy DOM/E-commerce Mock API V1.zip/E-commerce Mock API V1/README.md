````
npm install
npm run dev
````

http://localhost:5000